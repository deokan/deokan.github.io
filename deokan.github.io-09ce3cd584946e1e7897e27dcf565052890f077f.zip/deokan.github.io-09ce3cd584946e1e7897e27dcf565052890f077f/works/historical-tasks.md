1. DB cleansing 작업에 따른 상품 data 불일치
   - 2019-01-04 문의접수
   - admin화면에는 채널 및 재고 정보가 있으나 상품상세에서는 매진으로 노출된다는 문의
   - 확인결과 DB cleansing 작업대상 상품으로 mall DB만 data가 지워진 case
   - DB cleansing 작업을 언제, 누가, 왜, 어떤 대상 상품으로 진행하였는지, 또 왜 mall DB만 지워서 data 불일치 현상을 야기했는지?
   - 해당 hsitory를 모르는 현업과 mall 개발 담당자들은 업무수행에 큰 고충점.
